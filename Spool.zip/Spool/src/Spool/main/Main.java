//Author Vladislava Sicicorez
//Date 7/12/2021

//Following code will imitate an on-line streaming service "Spool". Customers will be able to sign/up or log-in into the service.
//There there are three different subscriptions available: Regular User, Prime User and Kids user.Uer can choose at the sign-up.
//Services are not available if the account balance in 0.

package Spool.main;

import Spool.models.User;
import Spool.view.UserViewLoginSignup;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException, InterruptedException {

        UserViewLoginSignup session = new UserViewLoginSignup();//creating new object of View
        session.intro();// Calling method to open view


    }
}


