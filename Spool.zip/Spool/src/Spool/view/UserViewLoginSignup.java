package Spool.view;

import Spool.controller.NewUserControl;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class UserViewLoginSignup extends NewUserControl {

    //creating object for the new entry
    NewUserControl entry = new NewUserControl();
    String email = "";

    //method to guide user thru the sign-up or log-in proccess
    public void intro() throws IOException, InterruptedException {
        System.out.println("Welcome to Spool streaming service!");
        System.out.println("");
        System.out.println("Would you like to sign-up? Type Y for Yes or N if you have an existing account");
        Scanner scanner = new Scanner(System.in);
        String signinreturn = scanner.nextLine();

        if (signinreturn.matches("y|Y")) { // if user answers Yes, then the method will ask user for new information to create a new user
            System.out.println("Enter your e-mail address");
            Scanner scanner2 = new Scanner(System.in);
            String email = scanner.nextLine();

            String check = entry.verifyEmail(email); //this method will verify if e-mail already exists

            if (check == ("Exists")) {
                System.out.println("Account with this email already exists, please log-in or use different e-mail");
                System.out.println("");
                TimeUnit.SECONDS.sleep(2); //pause to allow user to read previous prompt
                intro();//user's session will restart if e-mail is already in use to allow user to create an account with new e-mail or log-in
            }

            Boolean validEmail = entry.validateEmail(email);////call to control method to validate the email

            if (validEmail == false) {
                TimeUnit.SECONDS.sleep(2);
                intro();//if e-mail in not valid, program will restart
            }

            System.out.println("Create your password:");//asking for password input
            Scanner scanner3 = new Scanner(System.in);
            String password = scanner.nextLine();

            System.out.println("Enter your First Name");//asking for First Name
            Scanner scanner4 = new Scanner(System.in);
            String firstName = scanner.nextLine();

            System.out.println("Enter your Last Name");//asking for Last Name
            Scanner scanner5 = new Scanner(System.in);
            String lastName = scanner.nextLine();

            System.out.println("Deposit funds (Enter amount of funds to deposit into your account)");//Ask the amount user would like to deposit
            Scanner scanner6 = new Scanner(System.in);
            String accountBalance = scanner.nextLine();

            System.out.println("Would you like to register as a regular user, Prime user or Kids user?(Prime users have access to prime content). Type R for Regular, P for Prime and K for Kids");//Ask the type of the account to create
            Scanner scanner7 = new Scanner(System.in);
            String accountType = scanner.nextLine();


            entry.dataEntry(email, password, firstName, lastName, accountBalance, accountType);///passing parameters to control method to pass it to model for recording in file
            entry.determineOptions(email);//passing e-mail to determine type of services available to this client based on subscription and funds

        } else //this code block is for exiting user/login
            {
            try {
                if (signinreturn.matches("N|n")) {

                    System.out.println("Enter your email address");
                    Scanner scanner8 = new Scanner(System.in);
                    String email = scanner.nextLine();

                    System.out.println("Enter your password");
                    Scanner scanner9 = new Scanner(System.in);
                    String password = scanner.nextLine();

                    Boolean passCheckRes = entry.checkCredentials(email, password);//making sure email and password match the records
                    if (passCheckRes == true) {
                        System.out.println("Login successful");
                        entry.determineOptions(email);
                    } else {
                        System.out.println("Email/password do not match our records, please try again ");//give another try if wrong credentials entered
                        while (passCheckRes != true) {
                            System.out.println("Enter your email address");
                            scanner8 = new Scanner(System.in);
                            email = scanner.nextLine();

                            System.out.println("Enter your password");
                            scanner9 = new Scanner(System.in);
                            password = scanner.nextLine();

                            passCheckRes = entry.checkCredentials(email, password);// checking type of services avaliable to this customer

                        }
                    }
                } else {
                    throw new IOException();////exception in case user entered a wrong selection -> will restart the view
                }

            } catch (IOException e) {
                System.out.println("You entered wrong letter");
                e.printStackTrace();
                intro();
            }

        }

    }





}


