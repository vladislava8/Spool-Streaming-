package Spool.models;

import java.io.*;
import java.util.Scanner;

public class User {

    private String userEmailAddress;
    private String password;
    private String firstName;
    private String lastName;
    private String accountBalance;
    private String userType;

    File file = new File("UserInfo.txt");

    public String toString(String email, String password, String firstName, String lastName, String accountBalance, String userType) {
        return (email + " " + password + " " + firstName + " " + lastName + " " + accountBalance + " " + userType);
    }

    public void write(String a) throws IOException {
        FileWriter fw = new FileWriter("UserInfo.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.append(a);
        out.append(System.lineSeparator());
        out.close();
    }

    public String findEmail(String email) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        String result = "";
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] item = line.split(" ");
            String emailField = item[0];
            if (emailField.equals(email)) {
                result = "found";
            } else {
                continue;
            }
        }
        return result;
    }

    public boolean isValid(String email) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(regex);
    }

    public boolean checkCredentials(String email, String pass) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        boolean validCredentials = false;
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] item = line.split(" ");
            String emailField = item[0];
            String password = item[1];

            if (emailField.equals(email) && password.equals(pass)) {
                return true;
            } else
                continue;

        }

        return false;
    }

    public String getUserType(String email) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] item = line.split(" ");
            String emailField = item[0];

            if (emailField.equals(email)) {
                if (Integer.parseInt(item[4])<1){
                    return ("E");
                }
                else {
                    return item[5];}
            } else
                continue;

        }return "Error";
    }

        public void viewOptions(){
            System.out.println("Available services:");
            System.out.println("Regular Subscription movies");
        }
    }










