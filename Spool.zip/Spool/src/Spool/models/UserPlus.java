package Spool.models;

import java.io.FileNotFoundException;

public class UserPlus extends UserKids {

    public void viewOptions() {
        System.out.println("Available services:");
        System.out.println("Prime Subscription movies");
    }
}
