package Spool.models;

import java.io.FileNotFoundException;

public class UserKids extends User {

    public void viewOptions()  {
        System.out.println("Available services:");
        System.out.println("Kids Subscription movies");
    }
}
