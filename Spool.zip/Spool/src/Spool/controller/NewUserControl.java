package Spool.controller;

import Spool.models.User;
import Spool.models.UserKids;
import Spool.models.UserPlus;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class NewUserControl extends User {

    User sessionUser = new User();


    public void dataEntry(String email, String password, String firstname, String lastname, String acbal, String type) throws IOException {

        String infoString = sessionUser.toString(email, password, firstname, lastname, acbal, type);
        sessionUser.write(infoString);
    }

    public String verifyEmail(String email) throws FileNotFoundException {
        String verify = sessionUser.findEmail(email);
        if (verify == "found") {
            return ("Exists");
        } else {
            return ("Doesn't exist");
        }

    }

    public Boolean validateEmail(String email) {
        Boolean valid = sessionUser.isValid(email);
        try {
            if (valid == true) {
                return true;
            } else {
                throw new IOException();
            }

        } catch (IOException e) {
            System.out.println("Invalid email format. Please enter email in example@mail.com format");
            e.printStackTrace();
            return false;
        }

    }

    public boolean checkCredentials(String email, String password) throws FileNotFoundException {
        Boolean credRes = sessionUser.checkCredentials(email, password);
        if (credRes == true) {
            return true;
        } else {
            return false;
        }

    }

    public void determineOptions(String email) throws FileNotFoundException {
        String type = getUserType(email);
        if (type.equals("R")) {
            String R = "R";
            User user = new User();
            user.viewOptions();
        } else if (type.equals("K")) {
            String K = "K";
            UserKids kids = new UserKids();
            kids.viewOptions();

        } else if (type.equals("P")) {
            String P = "P";
            UserPlus plus = new UserPlus();
            plus.viewOptions();
        } else if (type.equals("E")) {
            System.out.println("Not enough funds to use services");

        }

    }

}


